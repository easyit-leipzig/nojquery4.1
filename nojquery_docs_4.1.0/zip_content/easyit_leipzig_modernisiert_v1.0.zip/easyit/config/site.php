<?php
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';
try {
    $defaults = [
        'site_name' => 'easyIT Leipzig',
        'base_url' => 'https://easyit-leipzig.de',
        'base_path' => '',
        'phone' => '+49 1520 178 27 34',
        'email' => 'info@easyit-leipzig.de',
        'service_area' => 'Leipzig und Umgebung',
        'postal_address' => [
            'streetAddress' => 'An der Kotsche 1', 'postalCode' => '04207',
            'addressLocality' => 'Leipzig', 'addressRegion' => 'Sachsen', 'addressCountry' => 'DE'
        ],
        'logo' => 'assets/img/brand-logo.svg',
        'image' => 'assets/img/social-preview-1200x630.png',
        'price_range' => '€€', 'opening_hours' => [], 'geo' => [], 'same_as' => [],
        'owner' => 'Olaf Thiele',
        'default_title' => 'easyIT Leipzig | IT-Service, Beratung und Schulung',
        'default_description' => 'Persönlicher IT-Service in Leipzig für kleine Unternehmen und Privatkunden: IT-Check, Beratung, Hardware, Software, Sicherheit und Schulung.'
    ];
    $local = config_load_local('site.local.php');
    $site = array_replace($defaults, $local);
    $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $localHost = $host === 'localhost' || str_starts_with($host, 'localhost:') || $host === '127.0.0.1' || str_starts_with($host, '127.0.0.1:');
    if ($localHost) {
        $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
        $detected = preg_match('~^(/[^/]+)(?:/|$)~', $script, $m) === 1 ? $m[1] : '/easyit';
        if (!array_key_exists('base_url', $local) && config_env('SITE_BASE_URL') === null) $site['base_url'] = 'http://' . $host;
        if (!array_key_exists('base_path', $local) && config_env('SITE_BASE_PATH') === null) $site['base_path'] = $detected;
    }
    $site['phone'] = config_env('SITE_PHONE', (string)$site['phone']) ?? '';
    $site['email'] = config_env('SITE_EMAIL', (string)$site['email']) ?? '';
    $site['base_url'] = rtrim(config_env('SITE_BASE_URL', (string)$site['base_url']) ?? '', '/');
    $site['base_path'] = '/' . trim(config_env('SITE_BASE_PATH', (string)$site['base_path']) ?? '', '/');
    if ($site['base_path'] === '/') $site['base_path'] = '';
    $site['owner'] = config_env('SITE_OWNER', (string)$site['owner']) ?? '';
    if (!filter_var($site['base_url'], FILTER_VALIDATE_URL)) throw new ConfigurationException('SITE_BASE_URL ist ungültig.');
    if ($site['email'] !== '' && !filter_var($site['email'], FILTER_VALIDATE_EMAIL)) throw new ConfigurationException('SITE_EMAIL ist ungültig.');
    security_send_headers();
    $publicBasePath = rtrim((string)$site['base_path'], '/');
    if ($publicBasePath !== '' && PHP_SAPI !== 'cli' && !defined('EASYIT_PATH_REWRITE_ACTIVE')) {
        define('EASYIT_PATH_REWRITE_ACTIVE', true);
        ob_start(static fn(string $html): string => preg_replace_callback(
            '~\b(href|src|action)=(["\'])/((?!/)[^"\']*)\2~i',
            static fn(array $m): string => $m[1].'='.$m[2].($m[3] === ltrim($publicBasePath,'/') || str_starts_with('/'.$m[3], $publicBasePath.'/') ? '/'.$m[3] : $publicBasePath.'/'.$m[3]).$m[2],
            $html
        ) ?? $html);
    }
    return $site;
} catch (Throwable $e) { config_abort($e); }
