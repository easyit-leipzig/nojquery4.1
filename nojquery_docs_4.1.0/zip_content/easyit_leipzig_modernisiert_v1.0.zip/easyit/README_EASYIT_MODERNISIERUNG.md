# easyIT Leipzig – modernisierter Stand

Dieser Stand überträgt die alte Website auf die optische und technische Basis von `nh_hor`.

## Enthalten
- modernes responsives Layout und horizontale Navigation
- PHP-8-Struktur mit zentralen Includes und Konfiguration
- lokale Pfaderkennung für `http://localhost/easyit/`
- CSP-, Referrer-, Permissions- und Frame-Sicherheitsheader
- SEO-Metadaten, Canonicals, OpenGraph, Sitemap/PWA-Basis
- Kontaktformular mit CSRF, Honeypot, Rate Limit und SMTP-Konfiguration
- Admin- und Datenbankbasis aus `nh_hor`
- neue IT-Seiten: Leistungen, IT-Check, Hardware, Software, Sicherheit, Schulung, Unternehmen und Preise
- SQL-Migration für die IT-Navigation
- alte statische HTML-Seiten im Ordner `legacy/` als Referenz

## Lokale Installation
1. Ordner als `C:\xampp\htdocs\easyit` entpacken.
2. `config/database.local.php.example` nach `config/database.local.php` kopieren und Zugangsdaten eintragen.
3. Datenbankdump importieren und danach `database/migrations/2026-07-23_easyit_it_navigation.sql` ausführen.
4. SMTP in einer lokalen Konfigurationsdatei bzw. über Umgebungsvariablen konfigurieren.
5. Website über `http://localhost/easyit/` öffnen.

## Noch vor Produktion prüfen
- Anschrift, Telefon, E-Mail und Preisangaben
- AGB und Datenschutz rechtlich prüfen
- SMTP-/Hosting-Dienstleister im Datenschutz ergänzen
- produktive Datenbankzugänge außerhalb des Webroots speichern
