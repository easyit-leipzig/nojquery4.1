<?php
require_once __DIR__.'/Mailer.php';

class Contacts
{
    private PDO $db;
    private Mailer $mailer;

    public function __construct(PDO $db)
    {
        $this->db = $db;
        $this->mailer = new Mailer();
    }

    /**
     * Neue Kontaktanfrage speichern
     */
    public function create(array $data): int
    {
        $stmt = $this->db->prepare("
            INSERT INTO contacts
            (person_id, type, contact_value, subject, message, status)
            VALUES
            (:person_id, :type, :contact_value, :subject, :message, :status)
        ");

        $stmt->execute([
            'person_id' => $data['person_id'] ?? null,
            'type' => $data['type'] ?? 'contact_form',
            'contact_value' => $data['contact_value'],
            'subject' => $data['subject'] ?? '',
            'message' => $data['message'],
            'status' => 'new'
        ]);

        return (int)$this->db->lastInsertId();
    }

    /**
     * Kontakt abrufen
     */
    public function get(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM contacts WHERE id = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        return $data ?: null;
    }

    /**
     * Alle offenen Kontakte abrufen
     */
    public function getOpen(): array
    {
        $stmt = $this->db->query("
            SELECT * FROM contacts
            WHERE status != 'closed'
            ORDER BY created_at DESC
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Status einer Kontaktanfrage setzen
     */
    public function setStatus(int $id, string $status): bool
    {
        $stmt = $this->db->prepare("
            UPDATE contacts SET status = ? WHERE id = ?
        ");
        return $stmt->execute([$status, $id]);
    }

    /**
     * E-Mail für eine Kontaktanfrage senden
     */
    public function sendEmail(int $id, string $to): bool
    {
        $contact = $this->get($id);
        if (!$contact) return false;

        $success = $this->mailer->send(
            $to,
            $contact['subject'],
            $contact['message']
        );

        if ($success) {
            $this->setStatus($id, 'answered');
        }

        return $success;
    }
}