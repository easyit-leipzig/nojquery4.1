<?php
declare(strict_types=1);
require_once __DIR__ . '/database.php';
function default_horizontal_menu_items(): array { return [
 ['title'=>'Startseite','url'=>'/index.php'],
 ['title'=>'Leistungen','url'=>'/leistungen.php','children'=>[
   ['title'=>'IT-Check & Beratung','url'=>'/it-check.php'], ['title'=>'Hardware & Netzwerke','url'=>'/hardware.php'],
   ['title'=>'Software & Digitalisierung','url'=>'/software.php'], ['title'=>'IT-Sicherheit','url'=>'/it-sicherheit.php'],
   ['title'=>'Schulung & Support','url'=>'/schulung.php']]],
 ['title'=>'Unternehmen','url'=>'/unternehmen.php'], ['title'=>'Preise','url'=>'/preise.php'], ['title'=>'Kontakt','url'=>'/kontakt.php']
]; }
function horizontal_menu_items(): array {
 if (!db_available()) return default_horizontal_menu_items();
 try { $rows=db()->query('SELECT id,parent_id,title,url,sort_order,is_active FROM navigation_items WHERE is_active<>0 ORDER BY sort_order,id')->fetchAll(PDO::FETCH_ASSOC); }
 catch(Throwable $e){ return default_horizontal_menu_items(); }
 if(!$rows) return default_horizontal_menu_items();
 $ids=[]; foreach($rows as $r)$ids[(int)$r['id']]=true; $by=[];
 foreach($rows as $r){$p=($r['parent_id']===null||(int)$r['parent_id']===0)?0:(int)$r['parent_id']; if($p!==0&&!isset($ids[$p]))$p=0; $by[$p][]=['id'=>(int)$r['id'],'title'=>(string)$r['title'],'url'=>trim((string)$r['url'])?:'#','sort_order'=>(int)$r['sort_order']];}
 $build=function(int $p,array $trail=[])use(&$build,$by):array{$out=[];foreach($by[$p]??[]as$r){if(in_array($r['id'],$trail,true))continue;$i=['title'=>$r['title'],'url'=>$r['url']];$c=$build($r['id'],[...$trail,$r['id']]);if($c)$i['children']=$c;$out[]=$i;}return$out;};
 return $build(0) ?: default_horizontal_menu_items();
}
function horizontal_menu_active(array $item): bool {$cur=basename((string)($_SERVER['SCRIPT_NAME']??'index.php'));$path=parse_url((string)$item['url'],PHP_URL_PATH);if(is_string($path)&&$path!==''&&$path!=='#'&&basename($path)===$cur)return true;foreach($item['children']??[]as$c)if(horizontal_menu_active($c))return true;return false;}
function render_horizontal_menu(array $items,int $level=1,string $idPrefix='menu'):string{$h='<ul class="'.($level===1?'menu level-1':'submenu level-'.$level).'">';foreach($items as$n=>$i){$c=$i['children']??[];$cls=[];if($c)$cls[]='has-submenu';if(horizontal_menu_active($i))$cls[]='is-active';$id=$idPrefix.'-'.$level.'-'.$n;$h.='<li'.($cls?' class="'.implode(' ',$cls).'"':'').'>';if($c){$h.='<div class="menu-entry"><a class="menu-link" href="'.e(app_path($i['url'])).'">'.e($i['title']).'</a><button class="submenu-button" type="button" aria-expanded="false" aria-controls="'.e($id).'" aria-label="Untermenü öffnen"><span aria-hidden="true">▾</span></button></div><div id="'.e($id).'" class="submenu-panel">'.render_horizontal_menu($c,$level+1,$id).'</div>';}else{$h.='<a class="menu-link" href="'.e(app_path($i['url'])).'">'.e($i['title']).'</a>';}$h.='</li>';}return$h.'</ul>';}
