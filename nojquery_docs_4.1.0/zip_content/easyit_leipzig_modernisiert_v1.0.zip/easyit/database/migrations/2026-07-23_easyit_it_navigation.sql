START TRANSACTION;
DELETE FROM navigation_items;
INSERT INTO navigation_items (id,parent_id,title,url,sort_order,is_active) VALUES
(1,NULL,'Startseite','/index.php',10,1),(2,NULL,'Leistungen','/leistungen.php',20,1),
(3,2,'IT-Check & Beratung','/it-check.php',10,1),(4,2,'Hardware & Netzwerke','/hardware.php',20,1),
(5,2,'Software & Digitalisierung','/software.php',30,1),(6,2,'IT-Sicherheit','/it-sicherheit.php',40,1),
(7,2,'Schulung & Support','/schulung.php',50,1),(8,NULL,'Unternehmen','/unternehmen.php',30,1),
(9,NULL,'Preise','/preise.php',40,1),(10,NULL,'Kontakt','/kontakt.php',50,1);
COMMIT;
